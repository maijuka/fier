Fier_ext, Fier_full and Fier_init experiments

Running the algorithm with settings_MammalsW_extonce.xml runs the Fier_ext algorithm on the MammalsW dataset, extending the given initial pairs once (section 3.3 paragraph "Extending once" and Fig. 4) with parameters b_h=30, r_h=20.

settings_MammalsW_ext.xml runs otherwise similar Fier_ext experiment, but extends the given initial pairs multiple times (section 3.3 paragraph "Extending multiple times" and Table 4).

settings_MammalsW_full.xml runs the Fier_full algorithm, first mining the initial pairs using Fier_init with parameters b_j=40 and r_j=10, and then extending multiple times (section 3.4 and Table 5).

settings_MammalsW_init.xml runs the Fier_init algorithm, mining only the initial pairs with b_j=40 and r_j=10 (section 3.2, Fig. 3 and Table 2).


ReReMi experiments

settings_MammalsW_ReReMi_extonce.xml extends the given intial pairs once with the ReReMi algorithm (section 3.3 paragraph "Extending once" and Fig. 4).

settings_MammalsW_ReReMi_init.xml mines the initial pairs using the ReReMi algorithm (section 3.2, Fig. 2 and Table 2).

settings_MammalsW_ReReMiBKT_init.xml mines the initial pairs using the ReReMiBKT algorithm (section 3.2, Fig. 2, Fig. 3 and Table 2).

settings_MammalsW_ReReMi_ext.xml extends the given initial pairs multiple times using the ReReMi algorithm (section 3.3, Table 4)

settings_MammalsW_ReReMi_full.xml mines the initial pairs using ReReMi and then extends them multiple times (section 3.4, Table 5).

settings_MammalsW_ReReMiBKT_full.xml mines the initial pairs using ReReMiBKT and then extends them multiple times (section 3.4, Table 5).













